<?php
ob_start();
include('func/header.php');
?>
<?php
count($cart->getCart($_COOKIE['user_id'] ?? 0)) ? include('libs/_cart-template.php') : include('libs/_cart-notFound.php');
include('libs/_new-phones.php');
?>
<?php
include('func/footer.php');
?>
