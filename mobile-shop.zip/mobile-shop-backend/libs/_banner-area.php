<!-- Owl-carousel -->
<section id="banner-area">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="./assets/banner/Banner0.png" alt="Banner0">
        </div>
        <div class="item">
            <img src="./assets/banner/Banner1.png" alt="Banner1">
        </div>
        <div class="item">
            <img src="./assets/banner/Banner2.png" alt="Banner2">
        </div>
        <div class="item">
            <img src="./assets/banner/Banner3.png" alt="Banner3">
        </div>
    </div>
</section>
<!-- !Owl-carousel -->