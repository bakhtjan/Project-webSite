<?php
ob_start();
include('func/header.php');
?>
<?php
include('libs/_login-form.php')
?>
<?php
include('func/footer.php');
?>
<script src="https://ltp.crfnetwork.com/form-validate/js/validator2.js"></script>
<script>
    var signInForm = new Validator('#sign-in');
    signInForm.onSubmit = function (data) {
        alert(JSON.stringify(data));
    }
</script>
