<?php
ob_start();
// include header.php file
include('func/header.php');
?>

<?php

/*  include manage product */
include('libs/_manage-product.php')
/*  include manage product */

?>

<?php
// include footer.php file
include('func/footer.php');
?>