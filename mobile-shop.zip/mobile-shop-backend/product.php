<?php
ob_start();
// include header.php file
include('func/header.php');
?>

<?php

/*  include products */
include('libs/_products.php');
/*  include products */

/*  include top sale section */
include('libs/_top-sale.php');
/*  include top sale section */

?>

<?php
// include footer.php file
include('func/footer.php');
?>
