<?php
ob_start();
include('func/header.php');
?>
<?php
include('libs/_register-form.php')
?>
<?php
include('func/footer.php');
?>

<script src="https://ltp.crfnetwork.com/form-validate/js/validator2.js"></script>
<script>
    var signUpForm = new Validator('#sign-up');
    signUpForm.onSubmit = function (data) {
        alert(JSON.stringify(data));
    }
</script>
